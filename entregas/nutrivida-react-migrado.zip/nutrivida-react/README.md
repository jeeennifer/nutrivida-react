# NutriVida React

Migración del sitio **NutriVida — Clínica de Asesoría Nutricional** a **React + Vite + React Bootstrap**. Conserva el contenido, las imágenes, la identidad visual y los flujos del proyecto original: planes nutricionales, reservas de citas, pacientes, blog, equipo clínico y panel administrador.

| Repositorio | Papel en esta versión |
|---|---|
| `jeeennifer/nutrivida` | Fuente de textos, imágenes, estilos visuales, datos y reglas de funcionamiento |
| `jeeennifer/tienda-react` | Referencia de Atomic Design, separación Container/Presentational y comentarios por responsabilidad |
| `jeeennifer/nutrivida-react` | Proyecto destino: Vite, React, Bootstrap y esta migración |

**Stack:** React 19 · Vite 8 · React Router 7 · React Bootstrap 2 · Bootstrap 5 · JavaScript con módulos ES · Oxlint.

**Pruebas unitarias postergadas:** este proyecto no configura Vitest, no incorpora archivos de test ni añade dependencias de testing. La verificación de esta entrega se realiza mediante compilación, análisis estático y recorridos funcionales en navegador.

---

## 1. Cómo levantarlo

Recomendado: **Node.js 24 LTS** y npm. `.nvmrc` contiene `24`. Vite requiere Node.js 20.19+ o 22.12+, pero la versión comprobada para esta entrega es Node.js 24.

Descomprime el ZIP y abre una terminal dentro de la carpeta `nutrivida-react`:

```bash
node --version
npm install
npm run dev
```

Abre la dirección que indique Vite en tu terminal. En una instalación local normal utiliza el puerto **5173**; si está ocupado, Vite puede elegir otro. No abras `index.html` haciendo doble clic: la aplicación necesita el servidor de Vite.

| Comando | Qué hace |
|---|---|
| `npm install` | Instala las dependencias del proyecto |
| `npm ci` | Reinstala exactamente las versiones del lockfile; útil en una instalación limpia |
| `npm run dev` | Inicia Vite con recarga automática |
| `npm run build` | Compila la aplicación de producción en `dist/` |
| `npm run preview` | Sirve la compilación generada para revisión local |
| `npm run lint` | Revisa el código con Oxlint |

Para revisar la compilación:

```bash
npm run build
npm run preview
```

No se necesitan variables `.env`, API keys, base de datos, cuentas externas ni un servidor backend. Todas las imágenes se incluyen en `public/assets/img/`; la interfaz no depende de bancos de imágenes externos.

El ZIP excluye `.git/`, `node_modules/`, `dist/`, cachés y archivos del entorno cloud. Estas carpetas se generan localmente cuando corresponde. No contiene datos personales del navegador usado en la verificación.

---

## 2. Estructura de carpetas

```text
nutrivida-react/
├── public/
│   └── assets/img/                 Imágenes originales de NutriVida
├── src/
│   ├── components/
│   │   ├── atoms/                  BotonNutrivida · EntradaCampo · EtiquetaCampo
│   │   │                           ImagenNutrivida · MensajeFormulario · PrecioPlan
│   │   ├── molecules/              CampoFormulario · ControlCupos · ResumenCita
│   │   │                           TarjetaPlan · TarjetaArticulo · TarjetaIntegrante
│   │   │                           TituloSeccion
│   │   ├── organisms/              Header · Footer · HeroNutricion · GrillaPlanes
│   │   │                           DetallePlan · ListaCarrito · ResumenCarrito
│   │   │                           CarritoLateral · FormularioNutrivida · ConfirmacionCita
│   │   │                           EquipoNutrivida · GrillaBlog · ArticuloBlog
│   │   │                           InicioAdministrador · TablaAdministrador
│   │   │                           AvisoCupos · PaginaNoEncontrada
│   │   ├── templates/              MainTemplate · PaginaTemplate
│   │   │                           PortadaTemplate · CarritoTemplate
│   │   └── pages/                  Una conexión explícita por vista lógica
│   ├── containers/
│   │   ├── NutrividaContainer.jsx   Estado compartido y operaciones de negocio
│   │   ├── contextoNutrivida.js     Contexto de datos
│   │   ├── useNutrivida.js          Acceso al contexto desde containers
│   │   ├── useFormulario.js         Valores, errores, mensajes y navegación diferida
│   │   ├── SitioContainer.jsx       Navegación, título, sesión y panel lateral
│   │   ├── AccesoContainer.jsx      Protección de rutas según sesión y rol
│   │   ├── InicioContainer.jsx      Selección de planes destacados
│   │   ├── PlanesContainer.jsx      Catálogo y apertura del panel de reserva
│   │   ├── DetallePlanContainer.jsx Resolución del ID y reserva de un plan
│   │   ├── CarritoContainer.jsx     Cantidades, resumen y acceso a la agenda
│   │   ├── AgendarCitaContainer.jsx Fecha, horario y confirmación
│   │   ├── ConfirmacionContainer.jsx Cita del paciente activo
│   │   ├── IngresoContainer.jsx     Validación de credenciales locales
│   │   ├── RegistroContainer.jsx    Registro de pacientes y duplicados
│   │   ├── ContactoContainer.jsx    Validación y confirmación local de contacto
│   │   ├── NosotrosContainer.jsx    Misión y equipos
│   │   ├── BlogContainer.jsx        Listado editorial
│   │   ├── ArticuloContainer.jsx    Artículo según parámetro de ruta
│   │   ├── InicioAdminContainer.jsx Accesos a mantenedores
│   │   ├── PlanesAdminContainer.jsx Listado y eliminación de planes
│   │   ├── PlanAdminContainer.jsx   Alta y edición de planes
│   │   ├── UsuariosAdminContainer.jsx Listado y eliminación de usuarios
│   │   ├── UsuarioAdminContainer.jsx Alta y edición de usuarios
│   │   └── RutaAnteriorContainer.jsx Compatibilidad con las URLs HTML anteriores
│   ├── utils/
│   │   ├── datosIniciales.js        Los cuatro planes y las cuentas de ejemplo originales
│   │   ├── contenido.js             Textos de portada, misión, equipos y artículos completos
│   │   ├── formularios.js           Etiquetas, opciones, ayudas y atributos de los campos
│   │   ├── validaciones.js          Reglas puras trasladadas del JavaScript original
│   │   ├── almacenamiento.js        Lectura/escritura con las claves originales
│   │   ├── formato.js               CLP, fechas, cantidades y sincronización de selección
│   │   ├── presentacion.js          Datos ya formateados para los componentes visuales
│   │   └── rutas.js                 Títulos del documento según la vista
│   ├── App.jsx                      Tabla de rutas
│   ├── App.css                      Estilos visuales de las secciones de NutriVida
│   ├── main.jsx                     Bootstrap CSS + BrowserRouter + provider
│   └── index.css                    Base global: tipografía, body y ajustes generales
├── index.html                       Documento en español, favicon y viewport
├── package.json
├── package-lock.json
├── vite.config.js
├── .oxlintrc.json
├── .gitignore
├── .nvmrc
└── README.md
```

**Convención:** un componente visual por archivo, nombres `PascalCase` y exportaciones con nombre. `App` conserva la exportación por defecto del punto de entrada. Los helpers y hooks usan nombres descriptivos en `camelCase`.

---

## 3. Arquitectura

### Atomic Design: cinco niveles exactos

| Nivel | Responsabilidad | Ejemplos | Estado propio de la aplicación |
|---|---|---|---|
| **Átomos** | Piezas visuales pequeñas | Botón, entrada, etiqueta, imagen, mensaje y precio | No |
| **Moléculas** | Combinaciones pequeñas de átomos | Campo con etiqueta/error, tarjeta de plan, control de cupos | No |
| **Organismos** | Secciones completas de la interfaz | Header, catálogo, formularios, tabla administrativa | No |
| **Templates** | Distribución y espacios de la página | Marco común, portada, columnas del carrito | No |
| **Pages** | Conexión de una vista/ruta con su estructura y container | `PlanesPage`, `AgendarCitaPage`, `PlanAdminPage` | No |

Las importaciones entre componentes fluyen hacia niveles inferiores:

```text
pages → templates → organisms → molecules → atoms
```

Un nivel puede utilizar directamente otro inferior. No hay importaciones hacia arriba ni entre archivos del mismo nivel. Los átomos no importan React Router; las moléculas y organismos pueden usar `Link` para representar navegación declarativa. Los hooks de navegación y la decisión de a dónde ir pertenecen a containers.

Los `containers/` quedan fuera de los cinco niveles: conectan estado y reglas con la UI. Las pages pueden conectar un container sin incorporar sus reglas en los componentes visuales.

### Container / Presentational

| El container decide | El componente presentacional recibe |
|---|---|
| Qué planes corresponden a la portada o a un ID | `planes`, `plan`, títulos y datos formateados |
| Cómo actualizar la selección y validar cupos | `items`, `total`, `onSumar`, `onRestar`, `onEliminar` |
| Si el usuario puede entrar a una ruta | La vista ya autorizada |
| Cómo validar y guardar un formulario | `valores`, `errores`, `mensaje`, `onChange`, `onSubmit` |
| Cuándo abrir el panel lateral o el menú | `abierto`, `expandido`, `onCerrar`, `onToggle` |

Los organismos, moléculas y átomos no usan `useState`, `useEffect`, `useContext`, `fetch`, `localStorage`, `querySelector` ni `innerHTML`. Muestran props y notifican eventos. Los componentes nativos de React Bootstrap se encargan de sus comportamientos internos de interfaz.

### Qué cambió desde HTML y JavaScript

| Antes | Ahora |
|---|---|
| Un documento HTML por vista | Un `Page` por vista lógica y rutas en `App.jsx` |
| Header/footer repetidos en cada archivo | `MainTemplate` con `Header` y `Footer` compartidos |
| `getElementById`, `innerHTML`, `createElement` | Renderizado declarativo con JSX y `map` |
| `addEventListener('submit', ...)` | `onSubmit` controlado desde el container |
| Lectura directa de `.value` | Valores de formulario en estado React |
| Redirecciones con `window.location.href` | `Link`, `Navigate` y `useNavigate` |
| Grillas CSS propias y media queries descendentes | `Container`, `Row`, `Col` y breakpoints mobile-first |
| Overlay y panel lateral manuales | `Offcanvas` de React Bootstrap, controlado por props |
| `alert()` al agotar cupos | Modal accesible con el mismo mensaje de disponibilidad |

### Comentarios por responsabilidad

Los archivos identifican su papel con `// ÁTOMO`, `// MOLÉCULA`, `// ORGANISMO`, `// TEMPLATE`, `// PAGE`, `// CONTAINER` o `// UTILS`. Explican qué datos reciben y dónde vive la lógica, sin trasladar comentarios o reglas de la tienda al dominio nutricional.

---

## 4. Vistas y enrutamiento

| Vista del original | Ruta React | Page |
|---|---|---|
| `index.html` | `/` | `InicioPage` |
| `planes.html` | `/planes` | `PlanesPage` |
| `detalle-plan.html?id=1` | `/planes/1` | `DetallePlanPage` |
| `nosotros.html` | `/nosotros` | `NosotrosPage` |
| `blog.html` | `/blog` | `BlogPage` |
| `blog-detalle-1.html` | `/blog/1` | `ArticuloPage` |
| `blog-detalle-2.html` | `/blog/2` | `ArticuloPage` |
| `blog-detalle-3.html` | `/blog/3` | `ArticuloPage` |
| `contacto.html` | `/contacto` | `ContactoPage` |
| `login.html` | `/login` | `IngresoPage` |
| `registro.html` | `/registro` | `RegistroPage` |
| `carrito.html` | `/carrito` | `CarritoPage` |
| `agendar-cita.html` | `/agendar-cita` | `AgendarCitaPage` |
| `cita-confirmada.html` | `/cita-confirmada` | `ConfirmacionPage` |
| `admin-home.html` | `/admin` | `InicioAdminPage` |
| `admin-planes.html` | `/admin/planes` | `PlanesAdminPage` |
| `admin-plan-form.html` | `/admin/planes/nuevo` | `PlanAdminPage` |
| `admin-plan-form.html?id=1` | `/admin/planes/1/editar` | `PlanAdminPage` |
| `admin-usuarios.html` | `/admin/usuarios` | `UsuariosAdminPage` |
| `admin-usuario-form.html` | `/admin/usuarios/nuevo` | `UsuarioAdminPage` |
| `admin-usuario-form.html?run=111111111` | `/admin/usuarios/111111111/editar` | `UsuarioAdminPage` |
| Dirección desconocida | `*` | `NoEncontradaPage` |

Las 19 direcciones HTML originales se aceptan como marcadores antiguos y redirigen a sus equivalentes React. Ningún enlace nuevo de la interfaz utiliza `.html`. Un ID de plan o artículo inexistente regresa al listado correspondiente. Los tres artículos comparten una vista y conservan sus textos completos.

La agenda y la confirmación requieren una sesión válida. Las rutas `/admin/...` requieren además `tipo: 'Administrador'`; el rol `Nutricionista` mantiene el comportamiento del original y no accede al panel de administración.

Para desplegar en un hosting estático, compila `dist/` y configura el servidor para devolver `index.html` en rutas que no sean archivos reales. Vite ya resuelve esto en desarrollo y preview. Esta versión utiliza la raíz del dominio; un despliegue en una subcarpeta requiere adaptar `base`, las rutas de recursos y el `basename` de BrowserRouter.

---

## 5. Funcionamiento y persistencia

### Planes, cupos y reservas

1. La portada muestra los tres primeros planes; `/planes` muestra el catálogo completo.
2. **Ver detalle** abre la ficha con descripción extensa, precio e incluidos.
3. **Agendar** añade una unidad al carrito y abre el panel lateral del catálogo.
4. **Mis Horas** permite sumar, restar hasta un mínimo de una unidad, eliminar o vaciar la selección. El contador del header suma unidades, no solo tipos de plan.
5. No se puede añadir una cantidad superior a los cupos disponibles. Los cupos se descuentan al confirmar, no al agregar al carrito.
6. **Confirmar y agendar** exige una selección y una sesión. Si falta la sesión, guarda el destino y regresa a la agenda después de ingresar como paciente.
7. Se eligen fecha y horario. Se rechazan fechas anteriores al día local y horarios fuera de las opciones originales: **09:00, 10:00, 11:00, 12:00, 15:00, 16:00 y 17:00**.
8. Antes de descontar cupos se comprueban todos los planes. Si falta alguno o perdió disponibilidad, se informa sin descontar parcialmente la reserva.
9. La confirmación guarda la cita, descuenta las unidades y vacía la selección. La página final muestra solo la última cita del correo activo.

La fecha representa el día elegido; no se convierte a UTC para mostrarla. La aplicación reproduce el modelo del original: los cupos son existencias globales por plan y no una agenda de disponibilidad independiente por día y profesional.

### Cuentas y validaciones

- Correos admitidos: `@duoc.cl` y `@gmail.com`, sin distinguir mayúsculas, con máximo de 100 caracteres.
- Contraseña: mínimo de **6 caracteres**, como la validación original. El texto de ayuda heredado de ingreso/registro menciona 6 a 10, pero la regla original no impone un máximo.
- RUN: 8 o 9 caracteres, sin puntos ni guion, dígitos y un dígito o `K` al final. Se conserva la validación de formato del original; no se aplica cálculo de módulo 11.
- Registro: nombre de 2 a 50 caracteres; apellidos de 2 a 100; correo y RUN únicos.
- Contacto: nombre de 2 a 100 caracteres y mensaje de 10 a 500.
- Los errores se muestran junto al campo y en un mensaje general, sin enviar el formulario por HTML.

### Panel administrador

La cuenta de demostración procede del proyecto original:

| Correo | Contraseña | Tipo |
|---|---|---|
| `admin@gmail.com` | `Admin123` | Administrador |

El usuario de ejemplo `paciente@duoc.cl` no tenía contraseña en el original. Para recorrer el flujo de paciente, crea una cuenta desde **Regístrate aquí**, o asigna una contraseña a ese usuario desde el panel.

**Planes:** alta, edición y eliminación; nombre de 3 a 100 caracteres; categoría de 2 a 50; precio no negativo; cupos enteros no negativos. Los incluidos se escriben uno por línea. Editar conserva la imagen y actualiza la selección existente; eliminar también retira el plan del carrito. Los planes nuevos usan la imagen genérica original `plan-consulta.jpg`.

**Usuarios:** alta, edición y eliminación, con roles Administrador, Nutricionista o Paciente. El RUN queda bloqueado durante la edición. Dejar la contraseña vacía al editar conserva la existente; al crear una cuenta, la contraseña es obligatoria. Se comprueban duplicados por RUN/correo. Los cambios del propio rol o la eliminación de la cuenta activa se reflejan en el acceso al panel.

### Claves de localStorage

| Clave | Contenido |
|---|---|
| `planes` | Catálogo y cupos actuales |
| `usuarios` | Cuentas de demostración y cuentas creadas localmente |
| `carrito` | Planes seleccionados con cantidad |
| `sesionActiva` | Indicador de sesión local |
| `correoSesion` | Correo de la cuenta activa |
| `nombreSesion` | Nombre mostrado en el header |
| `destinoTrasLogin` | Regreso a la agenda tras ingresar |
| `ultimaCita` | Última confirmación, fecha, hora, total y correo del paciente |

El estado se inicializa desde estas claves y se mantiene al recargar. Los datos se aíslan por origen del navegador: cambiar de puerto o dominio no transfiere automáticamente el almacenamiento. Las pestañas del mismo origen se sincronizan mediante el evento `storage`. Cerrar sesión limpia la selección y el destino pendiente, conservando los planes y usuarios guardados.

Los datos iniciales se utilizan cuando no existe una lista guardada o el JSON no se puede leer. Para reiniciar la demostración, elimina **solo las claves de NutriVida** desde las herramientas del navegador y recarga. Esto elimina las cuentas y reservas locales que hayas creado; no lo hagas si quieres conservarlas.

### Alcance del modelo original

La autenticación, las contraseñas y las reservas se simulan en el navegador para el proyecto académico; no son autenticación ni almacenamiento de un servicio clínico real. El formulario de contacto conserva el mensaje de éxito original, pero no envía emails ni realiza peticiones HTTP. Para un sistema real, estas funciones necesitan un backend y autenticación del lado del servidor. Utiliza cuentas y datos de demostración.

---

## 6. Diseño responsivo y apariencia

- `index.html` está en español e incluye `<meta name="viewport" content="width=device-width, initial-scale=1" />`.
- La grilla de planes y blog utiliza `Col xs={12} md={6} lg={4}`: una, dos y tres tarjetas por fila.
- El equipo clínico utiliza `xs={12} md={6} lg={3}` y conserva los cuatro profesionales.
- El equipo de desarrollo utiliza `xs={12} md={6} lg={4}`.
- La portada y el detalle usan dos columnas desde `md`, con la imagen primero en móvil para la portada.
- El carrito pasa de una a dos columnas desde `lg`.
- El header usa `Navbar expand="lg"` y un menú controlado desde el container; se cierra después de navegar.
- Las imágenes usan `Image fluid`; fotos de perfil y miniaturas conservan sus dimensiones y recorte.
- Las tablas usan `Table responsive`: si hace falta, se desplaza la tabla sin desbordar toda la página.
- `Offcanvas` y `Modal` aportan cierre, manejo del foco y navegación por teclado.

Los estilos se separan por responsabilidad:

- `src/index.css`, importado en `src/main.jsx`, conserva la base global: Arial, colores base, body, encabezados y ajustes generales.
- `src/App.css`, importado en `src/App.jsx`, conserva los estilos de las secciones de NutriVida: portada, tarjetas, formularios, equipo, blog, carrito y administración, incluidos fondos, bordes, sombras, radios y refinamientos responsive.

La distribución de columnas usa React Bootstrap y no `display: grid` ni `grid-template-columns` propios. Separar los archivos organiza el CSS; ambos siguen siendo hojas de estilos globales, no CSS Modules. `App.css` contiene estilos de NutriVida en lugar de los ejemplos de Vite.

La portada de escritorio se cotejó con el original: coincide la geometría del hero, su imagen y la primera tarjeta a 1440 px. El menú colapsable y los saltos de columnas se adaptan a los breakpoints pedidos de Bootstrap.

### Verificación funcional sin unit tests

Antes de dar por terminada una modificación, revisa en navegador:

- [ ] Portada, catálogo, detalle, equipo, blog y los tres artículos completos.
- [ ] Imágenes locales cargadas, sin errores en la consola.
- [ ] Contacto: errores de campos, correo no permitido y confirmación local.
- [ ] Registro: alta correcta y duplicados por RUN/correo.
- [ ] Ingreso: contraseña incorrecta, sesión correcta y cierre de sesión.
- [ ] Reserva: panel lateral, cantidades, persistencia al recargar y selección vacía.
- [ ] Regreso a la agenda después de ingresar, fecha/horario y confirmación.
- [ ] Descuento de cupos; bloqueo de planes agotados o modificados antes de confirmar.
- [ ] Administración de planes y usuarios: crear, editar, eliminar y permisos.
- [ ] Contraseña conservada al editar sin cambiarla y RUN de edición bloqueado.
- [ ] Menú móvil y ausencia de scroll horizontal a 360×740, 768×1024 y 1440×900.
- [ ] URLs antiguas redirigidas y recarga directa de rutas profundas.
- [ ] `npm run build` y `npm run lint` terminan correctamente.

Esta lista es una guía de verificación manual, no una suite de tests. Las pruebas unitarias se incorporarán en una etapa posterior, cuando se soliciten.

---

## 7. Convenciones de trabajo con Git

El ZIP no incluye el historial `.git`. Si ya tienes `nutrivida-react` clonado, copia los archivos de la entrega sobre tu carpeta de trabajo, conservando tu propio `.git`, revisa los cambios y trabaja en una rama. No necesitas crear un segundo repositorio ni modificar `nutrivida` o `tienda-react`.

### Ramas

`main` representa la versión estable; se recomienda integrar mediante Pull Request. Nombres en minúsculas, con guiones:

| Prefijo | Ejemplo |
|---|---|
| `feature/` | `feature/migracion-nutrivida-react` |
| `fix/` | `fix/reserva-cupos` |
| `refactor/` | `refactor/formularios-controlados` |
| `docs/` | `docs/guia-nutrivida` |
| `style/` | `style/responsive-equipo` |

### Commits

Formato: `tipo(alcance): descripción breve en minúsculas`.

```text
feat(atoms): crear boton e imagen de nutrivida
feat(organisms): mostrar catalogo de planes
feat(containers): conservar reserva al iniciar sesion
fix(admin): mantener contraseña al editar usuario
style(responsive): adaptar el equipo con columnas bootstrap
docs: explicar ejecucion y persistencia local
```

Cada integrante debe configurar su propio nombre y correo y realizar sus commits; no atribuyas trabajo de otra persona a tu cuenta. Mantén los cambios pequeños y revisables. `.gitignore` excluye dependencias, builds y archivos locales.

### Flujo sugerido

```bash
git switch -c feature/migracion-nutrivida-react
npm install
npm run dev
npm run build
npm run lint
git status
# Revisa y selecciona los archivos que quieras incluir.
git add src public index.html package.json package-lock.json README.md .nvmrc
git commit -m "feat: migrar nutrivida a react con atomic design"
git push -u origin feature/migracion-nutrivida-react
```

Abre el Pull Request y solicita la revisión de un integrante del equipo. No subas `node_modules/` ni `dist/`.

### Checklist antes del Pull Request

- [ ] Cada componente está en su nivel y no importa niveles superiores.
- [ ] Toda regla de estado, sesión, persistencia o navegación imperativa está en containers.
- [ ] Los componentes visuales reciben sus datos y eventos por props.
- [ ] Los textos y el diseño siguen el sitio original de NutriVida.
- [ ] Los flujos de paciente y administrador funcionan en móvil y escritorio.
- [ ] La compilación y Oxlint pasan.
- [ ] No se añadieron tests ni configuración de testing en esta etapa.

---

## 8. Errores frecuentes y lectura académica

| Situación | Qué revisar |
|---|---|
| Vite indica que Node no es compatible | Usa Node 24 y reinstala dependencias |
| Falta `react-router-dom` u otro módulo | Ejecuta `npm install` en la carpeta que contiene `package.json` |
| La página queda vacía al abrir el HTML directamente | Ejecuta `npm run dev`; no utilices `file://` |
| Recargar una ruta falla al desplegar | Configura el fallback del hosting a `index.html` |
| Un correo se rechaza | El original admite únicamente `duoc.cl` y `gmail.com` |
| El paciente de ejemplo no puede entrar | Crea una cuenta o asigna contraseña desde el administrador |
| Un plan no permite agregar más unidades | Revisa sus cupos y la cantidad ya elegida |
| No se ven cambios en datos iniciales | Una lista previa en localStorage tiene prioridad sobre las semillas |
| Los datos cambian al usar otro puerto | localStorage pertenece al origen, incluido su puerto |
| El contacto muestra éxito pero no llega un email | El formulario reproduce una confirmación local del proyecto original |

Para estudiar la migración por bloques, el orden acordado es: **base → utils → atoms → molecules → organisms → templates → pages → containers**. En la Etapa 2 se entregará el código de **uno a tres archivos como máximo por turno**, con su ruta exacta y una explicación breve de la migración desde HTML/JS y del uso de React Bootstrap. Se esperará la confirmación de que funciona antes de pasar al siguiente bloque.

**Acuerdo para la Etapa 2:** se conservarán `src/index.css` para la base global y `src/App.css` para los estilos visuales de NutriVida. No se incorporarán los estilos de ejemplo de Vite ni se añadirán pruebas unitarias en esta etapa. Antes de preparar el primer bloque se comprobará si la carpeta local del estudiante conserva la base inicial de Vite o contiene la migración completa, para que los pasos sean compatibles con su estado real.
