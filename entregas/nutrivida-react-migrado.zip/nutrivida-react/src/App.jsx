import { Route, Routes } from 'react-router-dom'
import { SitioContainer } from './containers/SitioContainer'
import { AccesoContainer } from './containers/AccesoContainer'
import { RutaAnteriorContainer } from './containers/RutaAnteriorContainer'
import { InicioPage } from './components/pages/InicioPage'
import { PlanesPage } from './components/pages/PlanesPage'
import { DetallePlanPage } from './components/pages/DetallePlanPage'
import { NosotrosPage } from './components/pages/NosotrosPage'
import { BlogPage } from './components/pages/BlogPage'
import { ArticuloPage } from './components/pages/ArticuloPage'
import { ContactoPage } from './components/pages/ContactoPage'
import { IngresoPage } from './components/pages/IngresoPage'
import { RegistroPage } from './components/pages/RegistroPage'
import { CarritoPage } from './components/pages/CarritoPage'
import { AgendarCitaPage } from './components/pages/AgendarCitaPage'
import { ConfirmacionPage } from './components/pages/ConfirmacionPage'
import { InicioAdminPage } from './components/pages/InicioAdminPage'
import { PlanesAdminPage } from './components/pages/PlanesAdminPage'
import { PlanAdminPage } from './components/pages/PlanAdminPage'
import { UsuariosAdminPage } from './components/pages/UsuariosAdminPage'
import { UsuarioAdminPage } from './components/pages/UsuarioAdminPage'
import { NoEncontradaPage } from './components/pages/NoEncontradaPage'

// Compatibilidad de marcadores: los enlaces nuevos usan rutas de React Router.
const RUTAS_ANTERIORES = [
  ['index.html', '/'], ['planes.html', '/planes'], ['detalle-plan.html', '/planes', 'detalle'],
  ['nosotros.html', '/nosotros'], ['blog.html', '/blog'], ['blog-detalle-1.html', '/blog/1'],
  ['blog-detalle-2.html', '/blog/2'], ['blog-detalle-3.html', '/blog/3'],
  ['contacto.html', '/contacto'], ['login.html', '/login'], ['registro.html', '/registro'],
  ['carrito.html', '/carrito'], ['agendar-cita.html', '/agendar-cita'], ['cita-confirmada.html', '/cita-confirmada'],
  ['admin-home.html', '/admin'], ['admin-planes.html', '/admin/planes'],
  ['admin-plan-form.html', '/admin/planes/nuevo', 'plan'], ['admin-usuarios.html', '/admin/usuarios'],
  ['admin-usuario-form.html', '/admin/usuarios/nuevo', 'usuario'],
]

// APLICACIÓN: tabla de rutas. Los datos y acciones viven en los containers.
export default function App() {
  return <Routes><Route element={<SitioContainer />}>
    <Route index element={<InicioPage />} />
    <Route path="planes" element={<PlanesPage />} />
    <Route path="planes/:id" element={<DetallePlanPage />} />
    <Route path="nosotros" element={<NosotrosPage />} />
    <Route path="blog" element={<BlogPage />} />
    <Route path="blog/:id" element={<ArticuloPage />} />
    <Route path="contacto" element={<ContactoPage />} />
    <Route path="login" element={<IngresoPage />} />
    <Route path="registro" element={<RegistroPage />} />
    <Route path="carrito" element={<CarritoPage />} />
    <Route element={<AccesoContainer />}>
      <Route path="agendar-cita" element={<AgendarCitaPage />} />
      <Route path="cita-confirmada" element={<ConfirmacionPage />} />
    </Route>
    <Route element={<AccesoContainer administrador />}>
      <Route path="admin" element={<InicioAdminPage />} />
      <Route path="admin/planes" element={<PlanesAdminPage />} />
      <Route path="admin/planes/nuevo" element={<PlanAdminPage />} />
      <Route path="admin/planes/:id/editar" element={<PlanAdminPage />} />
      <Route path="admin/usuarios" element={<UsuariosAdminPage />} />
      <Route path="admin/usuarios/nuevo" element={<UsuarioAdminPage />} />
      <Route path="admin/usuarios/:run/editar" element={<UsuarioAdminPage />} />
    </Route>
    {RUTAS_ANTERIORES.map(([ruta, destino, tipo]) => <Route path={ruta} key={ruta} element={<RutaAnteriorContainer destino={destino} tipo={tipo} />} />)}
    <Route path="*" element={<NoEncontradaPage />} />
  </Route></Routes>
}
