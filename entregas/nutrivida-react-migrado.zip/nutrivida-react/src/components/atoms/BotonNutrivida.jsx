import { Button } from 'react-bootstrap'

// ÁTOMO: dibuja un botón; la acción siempre llega desde un container.
export function BotonNutrivida({ children, secundario = false, className = '', ...props }) {
  return <Button type="button" className={`boton ${secundario ? 'boton-secundario' : ''} ${className}`} {...props}>{children}</Button>
}
