import { Form } from 'react-bootstrap'

// ÁTOMO controlado: recibe valor y evento; no conserva estado propio.
export function EntradaCampo({ tipo = 'text', opciones = [], ...props }) {
  if (tipo === 'select') {
    return <Form.Select {...props}>{opciones.map((opcion) => <option key={opcion.value} value={opcion.value}>{opcion.label}</option>)}</Form.Select>
  }
  return <Form.Control as={tipo === 'textarea' ? 'textarea' : 'input'} type={tipo === 'textarea' ? undefined : tipo} {...props} />
}
