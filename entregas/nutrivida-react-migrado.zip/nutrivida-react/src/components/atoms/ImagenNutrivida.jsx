import { Image } from 'react-bootstrap'

// ÁTOMO: imagen fluida; no carga datos ni decide rutas.
export function ImagenNutrivida({ alt, ...props }) {
  return <Image fluid alt={alt} {...props} />
}
