// ÁTOMO: el container decide el mensaje y su tipo; aquí solo se muestra.
export function MensajeFormulario({ mensaje }) {
  if (!mensaje?.texto) return null
  return <p className={`mensaje-formulario ${mensaje.tipo}`} role={mensaje.tipo === 'error' ? 'alert' : 'status'}>{mensaje.texto}</p>
}
