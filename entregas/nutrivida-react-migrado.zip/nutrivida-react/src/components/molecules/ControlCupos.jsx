import { Button } from 'react-bootstrap'

// MOLÉCULA: contador de reservas. Las reglas de cupos están en el container.
export function ControlCupos({ item, onSumar, onRestar }) {
  return <div className="control-cantidad d-flex align-items-center gap-3">
    <Button className="btn-cantidad" variant="light" aria-label={`Restar cupo de ${item.nombre}`} disabled={item.cantidad <= 1} onClick={() => onRestar(item.id)}>−</Button>
    <span aria-label={`Cantidad de ${item.nombre}`}>{item.cantidad}</span>
    <Button className="btn-cantidad" variant="light" aria-label={`Sumar cupo de ${item.nombre}`} onClick={() => onSumar(item.id)}>+</Button>
  </div>
}
