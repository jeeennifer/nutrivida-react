import { ImagenNutrivida } from '../atoms/ImagenNutrivida'

// MOLÉCULA: ficha del equipo clínico o del equipo de desarrollo.
export function TarjetaIntegrante({ integrante }) {
  return <article className="tarjeta-equipo h-100">
    {integrante.imagen && <ImagenNutrivida className="foto-perfil" src={integrante.imagen} alt={integrante.nombre} />}
    <h3>{integrante.nombre}</h3><p>{integrante.cargo}</p>
  </article>
}
