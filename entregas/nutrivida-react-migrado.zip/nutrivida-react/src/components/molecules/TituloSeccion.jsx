// MOLÉCULA: jerarquía visual del original (subtítulo y encabezado).
export function TituloSeccion({ titulo, subtitulo, descripcion, subtituloDespues = false }) {
  return <div className="titulos-seccion">
    {!subtituloDespues && subtitulo && <p className="subtitulo">{subtitulo}</p>}
    <h2>{titulo}</h2>
    {subtituloDespues && subtitulo && <p className="subtitulo">{subtitulo}</p>}
    {descripcion && <p>{descripcion}</p>}
  </div>
}
