import { Col, Row } from 'react-bootstrap'
import { TituloSeccion } from '../molecules/TituloSeccion'
import { TarjetaIntegrante } from '../molecules/TarjetaIntegrante'

// ORGANISMO: equipo y misión originales, con columnas de Bootstrap.
export function EquipoNutrivida({ contenido }) {
  return <>
    <TituloSeccion titulo="Sobre Nosotros" subtitulo="Conoce a quienes dan vida a NutriVida" subtituloDespues />
    <div className="seccion-texto"><p><strong>Nuestra Misión:</strong> {contenido.mision}</p></div>
    <h3 className="titulo-centrado">Nuestro Equipo Clínico</h3>
    <Row className="nv-grilla grilla-equipo">{contenido.equipoClinico.map((integrante) => <Col xs={12} md={6} lg={3} key={integrante.nombre}><TarjetaIntegrante integrante={integrante} /></Col>)}</Row>
    <h3 className="titulo-centrado">Equipo de Desarrollo Web (DSY1104)</h3>
    <Row className="nv-grilla grilla-equipo grilla-desarrolladores">{contenido.equipoDesarrollo.map((integrante) => <Col xs={12} md={6} lg={4} key={integrante.nombre}><TarjetaIntegrante integrante={integrante} /></Col>)}</Row>
  </>
}
