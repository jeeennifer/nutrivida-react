import { Container } from 'react-bootstrap'

// ORGANISMO: pie de página del original, compartido por todas las vistas.
export function Footer({ lineas }) {
  return <footer className="footer-minimalista"><Container fluid className="contenedor">
    {lineas.map((linea) => <p key={linea}>{linea}</p>)}
  </Container></footer>
}
