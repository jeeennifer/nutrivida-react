import { Col, Row } from 'react-bootstrap'
import { TituloSeccion } from '../molecules/TituloSeccion'
import { TarjetaArticulo } from '../molecules/TarjetaArticulo'

// ORGANISMO: los tres artículos mantienen su contenido y orden originales.
export function GrillaBlog({ articulos }) {
  return <><TituloSeccion subtitulo="BLOG" titulo="Consejos y novedades de nutrición" />
    <Row className="nv-grilla">{articulos.map((articulo) => <Col xs={12} md={6} lg={4} key={articulo.id}><TarjetaArticulo articulo={articulo} /></Col>)}</Row>
  </>
}
