import { PaginaTemplate } from '../templates/PaginaTemplate'
import { PaginaNoEncontrada } from '../organisms/PaginaNoEncontrada'

// PAGE: alternativa explícita para rutas desconocidas.
export function NoEncontradaPage() {
  return <PaginaTemplate><PaginaNoEncontrada /></PaginaTemplate>
}
