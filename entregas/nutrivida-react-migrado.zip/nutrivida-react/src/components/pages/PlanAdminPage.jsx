import { PaginaTemplate } from '../templates/PaginaTemplate'
import { PlanAdminContainer } from '../../containers/PlanAdminContainer'

// PAGE ("/admin/planes/nuevo y /admin/planes/:id/editar"): instancia la estructura y conecta su container.
export function PlanAdminPage() {
  return <PaginaTemplate ><PlanAdminContainer /></PaginaTemplate>
}
