import { PaginaTemplate } from '../templates/PaginaTemplate'
import { UsuarioAdminContainer } from '../../containers/UsuarioAdminContainer'

// PAGE ("/admin/usuarios/nuevo y /admin/usuarios/:run/editar"): instancia la estructura y conecta su container.
export function UsuarioAdminPage() {
  return <PaginaTemplate ><UsuarioAdminContainer /></PaginaTemplate>
}
