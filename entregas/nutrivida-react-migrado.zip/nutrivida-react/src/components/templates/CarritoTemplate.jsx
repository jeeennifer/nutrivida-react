import { Col, Row } from 'react-bootstrap'
import { TituloSeccion } from '../molecules/TituloSeccion'
import { ListaCarrito } from '../organisms/ListaCarrito'
import { ResumenCarrito } from '../organisms/ResumenCarrito'

// TEMPLATE: dos columnas en escritorio y una en móvil; datos recibidos por props.
export function CarritoTemplate({ listado, resumen }) {
  return <><TituloSeccion titulo="Tu carrito" /><Row className="nv-carrito align-items-start">
    <Col xs={12} lg={8}><ListaCarrito {...listado} /></Col>
    <Col xs={12} lg={4}><ResumenCarrito {...resumen} /></Col>
  </Row></>
}
