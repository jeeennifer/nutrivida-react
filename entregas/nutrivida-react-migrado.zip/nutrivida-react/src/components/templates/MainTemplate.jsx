// TEMPLATE: estructura común con slots. No conoce datos, permisos ni rutas.
// header -> navegación; children -> página; footer -> pie; overlays -> paneles.
export function MainTemplate({ header, children, footer, overlays }) {
  return <div className="d-flex flex-column min-vh-100">{header}<main className="flex-grow-1">{children}</main>{footer}{overlays}</div>
}
