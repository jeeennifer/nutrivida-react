import { Container } from 'react-bootstrap'

// TEMPLATE: ancho y espaciado compartidos; el contenido llega por children.
export function PaginaTemplate({ children, portada = false, articulo = false }) {
  if (portada) return <>{children}</>
  return <Container fluid className={`contenedor seccion ${articulo ? 'articulo-blog' : ''}`}>{children}</Container>
}
