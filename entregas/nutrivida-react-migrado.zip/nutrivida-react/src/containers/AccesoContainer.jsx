import { useEffect } from 'react'
import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { useNutrivida } from './useNutrivida'

// CONTAINER: protege rutas; los organismos no conocen permisos ni redirecciones.
export function AccesoContainer({ administrador = false }) {
  const { sesion } = useNutrivida()
  const location = useLocation()
  useEffect(() => {
    if (!sesion && location.pathname === '/agendar-cita') localStorage.setItem('destinoTrasLogin', '/agendar-cita')
  }, [sesion, location.pathname])
  if (!sesion) return <Navigate to="/login" replace state={{ destino: location.pathname }} />
  if (administrador && sesion.tipo !== 'Administrador') return <Navigate to="/" replace />
  return <Outlet />
}
