import { useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import { useNutrivida } from './useNutrivida'
import { useFormulario } from './useFormulario'
import { FormularioNutrivida } from '../components/organisms/FormularioNutrivida'
import { FORMULARIOS } from '../utils/formularios'
import { fechaLocalActual, formatearPrecio } from '../utils/formato'
import { presentarReservas } from '../utils/presentacion'

// CONTAINER: fecha, horario, sesión y cupos se comprueban antes de confirmar.
export function AgendarCitaContainer() {
  const { carrito, total, confirmarCita } = useNutrivida()
  const form = useFormulario({ fecha: '', hora: '' })
  const [confirmada, setConfirmada] = useState(false)
  const navigate = useNavigate()
  const hoy = fechaLocalActual()
  const configuracion = { ...FORMULARIOS.cita, campos: FORMULARIOS.cita.campos.map((campo) => campo.name === 'fecha' ? { ...campo, min: hoy } : campo) }
  function enviar(evento) {
    evento.preventDefault()
    const { fecha, hora } = form.valores
    const horarios = FORMULARIOS.cita.campos.find((campo) => campo.name === 'hora').opciones.map((opcion) => opcion.value).filter(Boolean)
    if (!form.comprobar({ fecha: !fecha ? 'Selecciona un día para tu cita.' : fecha < hoy ? 'La fecha no puede ser anterior a hoy.' : '', hora: horarios.includes(hora) ? '' : 'Selecciona un horario.' })) return
    const resultado = confirmarCita(fecha, hora)
    if (resultado.sinSesion) { localStorage.setItem('destinoTrasLogin', '/agendar-cita'); navigate('/login'); return }
    if (resultado.error) { form.error(resultado.error); return }
    // Vaciar el carrito y completar la reserva pertenecen a la misma transición.
    // Así, la guarda de carrito vacío no interrumpe la página de confirmación.
    setConfirmada(true)
  }
  if (confirmada) return <Navigate to="/cita-confirmada" replace />
  if (carrito.length === 0) return <Navigate to="/planes" replace />
  return <FormularioNutrivida configuracion={configuracion} {...form} onSubmit={enviar} resumen={{ items: presentarReservas(carrito), total: formatearPrecio(total) }} />
}
