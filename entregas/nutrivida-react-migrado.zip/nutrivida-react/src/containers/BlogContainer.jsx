import { GrillaBlog } from '../components/organisms/GrillaBlog'
import { CONTENIDO } from '../utils/contenido'

// CONTAINER: aporta el contenido editorial, sin peticiones innecesarias.
export function BlogContainer() { return <GrillaBlog articulos={CONTENIDO.articulos} /> }
