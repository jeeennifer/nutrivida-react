import { GrillaBlog } from '../components/organisms/GrillaBlog'
import { ARTICULOS } from '../data/articulosData'

// CONTAINER: aporta el contenido editorial, sin peticiones innecesarias.
export function BlogContainer() { return <GrillaBlog articulos={ARTICULOS} /> }
