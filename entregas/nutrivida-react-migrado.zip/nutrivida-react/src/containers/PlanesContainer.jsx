import { useNutrivida } from './useNutrivida'
import { GrillaPlanes } from '../components/organisms/GrillaPlanes'
import { presentarPlan } from '../utils/presentacion'

// CONTAINER: conecta el catálogo y abre el panel al reservar un cupo.
export function PlanesContainer() {
  const { planes, agregarPlan } = useNutrivida()
  return <GrillaPlanes planes={planes.map(presentarPlan)} titulo="Elige el que se adapta a ti" subtitulo="NUESTROS PLANES" mostrarAgendar onAgendar={(id) => agregarPlan(id, true)} />
}
