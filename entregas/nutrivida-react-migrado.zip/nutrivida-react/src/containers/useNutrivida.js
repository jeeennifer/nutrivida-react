import { useContext } from 'react'
import { ContextoNutrivida } from '../context/NutriContext'

// HOOK de containers: centraliza el acceso a los datos de la clínica.
export function useNutrivida() {
  const contexto = useContext(ContextoNutrivida)
  if (!contexto) throw new Error('Usa el container dentro de NutrividaContainer.')
  return contexto
}
