// UTILS: funciones puras; no conocen React, el DOM ni el almacenamiento.
export function formatearPrecio(valor) {
  return `$${Number(valor).toLocaleString('es-CL')}`
}

export function fechaLocalActual() {
  const fecha = new Date()
  return `${fecha.getFullYear()}-${String(fecha.getMonth() + 1).padStart(2, '0')}-${String(fecha.getDate()).padStart(2, '0')}`
}

export function formatearFecha(valor) {
  return new Date(`${valor}T00:00:00`).toLocaleDateString('es-CL', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  })
}

export function totalPlanes(items) {
  return items.reduce((total, item) => total + item.precio * item.cantidad, 0)
}

export function sincronizarCarrito(selecciones, planes) {
  return selecciones.flatMap((item) => {
    const plan = planes.find((actual) => actual.id === item.id)
    if (!plan || !Number.isInteger(item.cantidad) || item.cantidad < 1) return []
    return [{ ...plan, cantidad: item.cantidad }]
  })
}

export function rutaImagen(imagen) {
  return `/${String(imagen).replace(/^\/+/, '')}`
}
