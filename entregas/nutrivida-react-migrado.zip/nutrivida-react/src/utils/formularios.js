// CONFIGURACIÓN: etiquetas y ayudas de los formularios originales.
export const FORMULARIOS = {
  "ingreso": {
    "titulo": "Iniciar Sesión",
    "descripcion": "Ingresa tus datos para confirmar tu agendamiento",
    "campos": [
      {
        "id": "email",
        "name": "correo",
        "label": "Correo Electrónico:",
        "tipo": "email",
        "placeholder": "ejemplo@correo.com",
        "autoComplete": "email"
      },
      {
        "id": "password",
        "name": "password",
        "label": "Contraseña:",
        "tipo": "password",
        "placeholder": "Entre 6 y 10 caracteres",
        "autoComplete": "current-password"
      }
    ],
    "textoBoton": "Ingresar y Confirmar",
    "pie": {
      "texto": "¿Aún no tienes cuenta?",
      "enlace": "Regístrate aquí",
      "to": "/registro"
    }
  },
  "registro": {
    "titulo": "Crear cuenta de paciente",
    "descripcion": "Regístrate para poder agendar tus citas",
    "campos": [
      {
        "id": "run-registro",
        "name": "run",
        "label": "RUN (sin puntos ni guion):",
        "tipo": "text",
        "maxLength": "9",
        "placeholder": "Ej: 19011022K"
      },
      {
        "id": "nombre-registro",
        "name": "nombre",
        "label": "Nombre:",
        "tipo": "text",
        "maxLength": "50"
      },
      {
        "id": "apellidos-registro",
        "name": "apellidos",
        "label": "Apellidos:",
        "tipo": "text",
        "maxLength": "100"
      },
      {
        "id": "email-registro",
        "name": "correo",
        "label": "Correo Electrónico:",
        "tipo": "email",
        "placeholder": "ejemplo@correo.com",
        "autoComplete": "email"
      },
      {
        "id": "password-registro",
        "name": "password",
        "label": "Contraseña:",
        "tipo": "password",
        "placeholder": "Entre 6 y 10 caracteres",
        "autoComplete": "new-password"
      }
    ],
    "textoBoton": "Crear cuenta",
    "pie": {
      "texto": "¿Ya tienes cuenta?",
      "enlace": "Ingresa aquí",
      "to": "/login"
    }
  },
  "contacto": {
    "titulo": "Contáctanos",
    "descripcion": "Envíanos tus dudas y te responderemos a la brevedad.",
    "campos": [
      {
        "id": "nombre-contacto",
        "name": "nombre",
        "label": "Nombre completo:",
        "tipo": "text",
        "placeholder": "Ej: Juan Pérez",
        "autoComplete": "name"
      },
      {
        "id": "email-contacto",
        "name": "correo",
        "label": "Correo Electrónico:",
        "tipo": "email",
        "placeholder": "ejemplo@correo.com",
        "autoComplete": "email"
      },
      {
        "id": "mensaje-contacto",
        "name": "mensaje",
        "label": "Tu mensaje:",
        "tipo": "textarea",
        "placeholder": "Escribe tu consulta aquí...",
        "rows": "5"
      }
    ],
    "textoBoton": "Enviar Mensaje"
  },
  "cita": {
    "titulo": "Agenda tu cita",
    "descripcion": "Elige el día y la hora en que quieres asistir.",
    "campos": [
      {
        "id": "fecha-cita",
        "name": "fecha",
        "label": "Fecha de la cita:",
        "tipo": "date"
      },
      {
        "id": "hora-cita",
        "name": "hora",
        "label": "Horario:",
        "tipo": "select",
        "opciones": [
          {
            "value": "",
            "label": "Selecciona un horario"
          },
          {
            "value": "09:00",
            "label": "09:00"
          },
          {
            "value": "10:00",
            "label": "10:00"
          },
          {
            "value": "11:00",
            "label": "11:00"
          },
          {
            "value": "12:00",
            "label": "12:00"
          },
          {
            "value": "15:00",
            "label": "15:00"
          },
          {
            "value": "16:00",
            "label": "16:00"
          },
          {
            "value": "17:00",
            "label": "17:00"
          }
        ]
      }
    ],
    "textoBoton": "Confirmar cita"
  },
  "planAdmin": {
    "titulo": "Nuevo plan",
    "descripcion": "",
    "campos": [
      {
        "id": "nombre-plan",
        "name": "nombre",
        "label": "Nombre del plan:",
        "tipo": "text",
        "maxLength": "100"
      },
      {
        "id": "etiqueta-plan",
        "name": "etiqueta",
        "label": "Categoría:",
        "tipo": "text",
        "maxLength": "50",
        "placeholder": "Ej: Nutrición Deportiva"
      },
      {
        "id": "descripcion-plan",
        "name": "descripcion",
        "label": "Descripción:",
        "tipo": "textarea",
        "maxLength": "500",
        "rows": "3"
      },
      {
        "id": "incluye-plan",
        "name": "incluye",
        "label": "¿Qué incluye el plan?",
        "tipo": "textarea",
        "rows": "4",
        "ayuda": "Escribe un elemento por línea."
      },
      {
        "id": "precio-plan",
        "name": "precio",
        "label": "Precio (CLP):",
        "tipo": "number",
        "min": "0",
        "step": "1"
      },
      {
        "id": "stock-plan",
        "name": "stock",
        "label": "Cupos disponibles:",
        "tipo": "number",
        "min": "0",
        "step": "1"
      }
    ],
    "textoBoton": "Guardar plan"
  },
  "usuarioAdmin": {
    "titulo": "Nuevo usuario",
    "descripcion": "",
    "campos": [
      {
        "id": "run-usuario",
        "name": "run",
        "label": "RUN (sin puntos ni guion):",
        "tipo": "text",
        "maxLength": "9",
        "placeholder": "Ej: 19011022K"
      },
      {
        "id": "nombre-usuario",
        "name": "nombre",
        "label": "Nombre:",
        "tipo": "text",
        "maxLength": "50"
      },
      {
        "id": "apellidos-usuario",
        "name": "apellidos",
        "label": "Apellidos:",
        "tipo": "text",
        "maxLength": "100"
      },
      {
        "id": "correo-usuario",
        "name": "correo",
        "label": "Correo electrónico:",
        "tipo": "email",
        "maxLength": "100"
      },
      {
        "id": "password-usuario",
        "name": "password",
        "label": "Contraseña:",
        "tipo": "password",
        "placeholder": "Mínimo 6 caracteres",
        "autoComplete": "new-password",
        "ayuda": "Al editar, deja este campo vacío para conservar la contraseña."
      },
      {
        "id": "tipo-usuario",
        "name": "tipo",
        "label": "Tipo de usuario:",
        "tipo": "select",
        "opciones": [
          {
            "value": "",
            "label": "Selecciona tipo"
          },
          {
            "value": "Administrador",
            "label": "Administrador"
          },
          {
            "value": "Nutricionista",
            "label": "Nutricionista"
          },
          {
            "value": "Paciente",
            "label": "Paciente"
          }
        ]
      }
    ],
    "textoBoton": "Guardar usuario"
  }
}
